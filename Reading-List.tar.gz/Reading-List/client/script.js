// Function for showing each CRUD Element
function goTo(x) {
    // Hide the options
    x.parentNode.style.display = "none";
    
    // Show the element
    document.getElementById(x.id.trim()).style.display = "block";
}

// Function to go back to the options menu
function goBack(x) {
    // Hide the element
    x.parentNode.parentNode.style.display = "none";
    
    // Show the options
    document.getElementById("options").style.display = "block";
}

// Now for the nitty gritty jQuery
$(document).ready(function() {
    
    // CREATE
    $("#submitCreate").click(function() {
        
        // Gather the from data
        var name = document.getElementById("cName").value;
        var URL = document.getElementById("cURL").value;
        var theDesc = document.getElementById("cTheDesc").value;
        
        // Create an object with the data
        var formData = {"name":name, "URL":URL, "theDesc":theDesc};
        
        // Turn the data into a JSON string
        var dataString = JSON.stringify(formData);
        
        // Stop the user submitting any empty fields
        if (name == "" || URL == "" || theDesc == "") {
            alert("Please fill in the empty fields.");
        } else {
            // Provided they filled the form in correctly, send the data
            $.ajax({
                type: "POST",
                url : "../service/rest.php",
                data: {readingListItem : dataString},
                
                // Tell the user if it worked / didn't work
                success: function() {
                    alert("Article added successfully.")
                },
                error: function(e) {
                    // alert("Error while adding article. Please try again later");
                }
            });
        }
    });
});
