<?php 

// Establish a connection with the database
$db = mysqli_connect("localhost", "root", "", "reading_list_app");

// Make sure the connection was made
if (!$db) {
    die("Connection to database failed.");
}

// If it was, we can now decode the JSON string
$dataString = $_POST['readingListItem'];
$formData = json_decode($dataString);

// Now we split the object into parts
$name = $formData->name;
$URL = $formData->URL;
$theDesc = $formData->theDesc;

// Now that we have an object with the data, we can insert it into the db
$sql = "INSERT INTO articles (theDate, name, URL, theDesc) VALUES (CURDATE(), '$name', '$URL', '$theDesc');";

// Check to make sure all went well, and report the status accordingly
if (mysqli_query($db, $sql)) {
    echo "Success!";
} else {
    echo "Query failed to execute $sql. " . mysqli_error($db);
}

?>